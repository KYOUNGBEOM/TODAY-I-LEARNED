1. Login 소스파일의 sysPw 값은 본인이 설정한 관리자 계정(sys as sysdba) 비밀번호로 변경 
2. 아이디:sqlid 비밀번호:sqlpw로 계정생성 후 memo.txt에 있는 쿼리문 실행
3. 프로그램 실행전 반드시 ojdbc8.jar를 class path로 추가
(프로젝트 우클릭 - Build Path - Configure Build Path - Java Bulid Path - classpath - Add External JARs)
4. 프로그램 실행