public class SudokuBean {
	private Object [][] sudoku_puzzle = new Object[9][9];

	public Object[][] getSudoku_puzzle() {
		return sudoku_puzzle;
	}

	public void setSudoku_puzzle(Object[][] sudoku_puzzle) {
		this.sudoku_puzzle = sudoku_puzzle;
	}
}